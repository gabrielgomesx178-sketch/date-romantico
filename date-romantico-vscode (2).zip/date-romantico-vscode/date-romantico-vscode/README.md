# Date Romântico 💗

Projeto simples em HTML, CSS e JavaScript inspirado no vídeo enviado.

## Como abrir no VS Code

1. Instale o VS Code.
2. Extraia este projeto.
3. Abra a pasta `date-romantico-vscode` no VS Code.
4. Abra o arquivo `index.html`.
5. Instale a extensão **Live Server**.
6. Clique com o botão direito em `index.html`.
7. Escolha **Open with Live Server**.

O site abrirá no navegador.

## Estrutura

- `index.html` → estrutura da página.
- `style.css` → visual, cores, cards e corações.
- `script.js` → perguntas, botões e navegação.

## Personalização

Você pode trocar os textos e emojis diretamente no `script.js`.

Exemplo:

`VOCÊ ACEITARIA SAIR COMIGO?`

pode virar:

`EM QUAL SABÁDO VOCÊ DESEJA?`

Também dá para trocar as opções de comida e de atividade no começo do arquivo `script.js`.
