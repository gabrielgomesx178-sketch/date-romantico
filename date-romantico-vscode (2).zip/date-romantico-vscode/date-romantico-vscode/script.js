const app = document.querySelector("#app");
const hearts = document.querySelector("#hearts");

let selectedFood = "";
let selectedVibe = "";

function createHearts() {
  const emojis = ["💜", "💖", "🩷", "🐶", "🥺"];
  for (let i = 0; i < 24; i++) {
    const heart = document.createElement("div");
    heart.className = "heart";
    heart.textContent = emojis[Math.floor(Math.random() * emojis.length)];
    heart.style.left = `${Math.random() * 100}%`;
    heart.style.setProperty("--size", `${14 + Math.random() * 18}px`);
    heart.style.setProperty("--duration", `${6 + Math.random() * 7}s`);
    heart.style.setProperty("--delay", `${Math.random() * -10}s`);
    hearts.appendChild(heart);
  }
}

function render(html) {
  app.innerHTML = html;
}

function start() {
  render(`
    <div class="card">
      <div class="emoji">🥺</div>
      <div class="question">Você aceitaria<br>sair cmg no sabádo?</div>
      <button class="btn" onclick="confirmation()">sim 💗</button>
    </div>
  `);
}

function confirmation() {
  render(`
    <div class="card">
      <div class="emoji">🥺</div>
      <div class="question">SÉRIO??</div>
      <p class="subtitle">Disse sim??? 💙</p>
      <button class="btn" onclick="nextStep()">Era só pra ter certeza 😎👌</button>
    </div>
  `);
}

function nextStep() {
  render(`
    <div class="card">
      <div class="emoji">☺️</div>
      <div class="question">Amémmm!! 💗</div>
      <p class="subtitle">Então agora vamos escolher o nosso date.</p>
      <button class="btn" onclick="dateStep()">próximo 💙</button>
    </div>
  `);
}

function dateStep() {
  render(`
    <div class="card">
      <h1>📅 QUANDO VOCÊ TÁ LIVRE?</h1>
      <p class="subtitle">Escolhe o sabádo e o horário ideal.</p>

      <div class="field">
        <label for="date">Escolha o sábado</label>
        <input id="date" type="date">
      </div>

      <div class="field">
        <label for="time">Escolha o horário</label>
        <input id="time" type="time">
      </div>

      <button class="btn" onclick="foodStep()">CONTINUAR A DATA 💗</button>
    </div>
  `);
}

const foods = [
  ["🍔", "Hambúrguer"],
  ["🍣", "Sushi"],
  ["🍝", "Massas"],
  ["🌮", "Tacos"],
  ["🍕", "Pizza"]
];

function foodStep() {
  const date = document.querySelector("#date").value;
  const time = document.querySelector("#time").value;

  if (!date || !time) {
    alert("Escolhe a data e o horário primeiro 😌");
    return;
  }

  render(`
    <div class="card">
      <h1>Oq tu mais quer?? 😌</h1>
      <p class="subtitle">Escolhe o que você gostaria de comer pfv linda.</p>

      <div class="options">
        ${foods.map(([emoji, name], index) => `
          <button class="option" onclick="selectFood(${index}, this)">
            <span>${emoji}</span>${name}
          </button>
        `).join("")}
      </div>

      <button class="btn" onclick="vibeStep()">Bó bb 💙</button>
    </div>
  `);
}

function selectFood(index, button) {
  selectedFood = foods[index][1];
  document.querySelectorAll(".option").forEach(btn => btn.classList.remove("selected"));
  button.classList.add("selected");
}

const vibes = [
  ["☕", "Café"],
  ["🚶", "Caminhada"],
  ["🎬", "Cinema"],
  ["💃", "Dança"],
  ["🌳", "Parque"],
  ["🏖️", "Praia"]
];

function vibeStep() {
  if (!selectedFood) {
    alert("Escolhe uma comida primeiro 😌");
    return;
  }

  render(`
    <div class="card">
      <h1>Qual vibe meu docinho de coco 🌼</h1>
      <p class="subtitle">Escolhe a atividade ideal.</p>

      <div class="options">
        ${vibes.map(([emoji, name], index) => `
          <button class="option" onclick="selectVibe(${index}, this)">
            <span>${emoji}</span>${name}
          </button>
        `).join("")}
      </div>

      <button class="btn" onclick="finish()">Acompanhar contigo né 😎</button>
    </div>
  `);
}

function selectVibe(index, button) {
  selectedVibe = vibes[index][1];
  document.querySelectorAll(".option").forEach(btn => btn.classList.remove("selected"));
  button.classList.add("selected");
}

function finish() {
  if (!selectedVibe) {
    alert("Escolhe uma atividade primeiro 😌");
    return;
  }

  render(`
    <div class="card">
      <div class="success">💘</div>
      <h1>Date confirmado 😭😭(choro de alegria)!</h1>
      <p class="subtitle">
        Comida: <strong>${selectedFood}</strong><br>
        Atividade: <strong>${selectedVibe}</strong>
      </p>
      <p class="question">Agora só falta a gente combinar os detalhes 😏</p>
      <button class="btn" onclick="start()">Começar de novo?? 💗</button>
    </div>
  `);
}

createHearts();
start();
